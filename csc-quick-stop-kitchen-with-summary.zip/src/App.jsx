import { useMemo, useState } from 'react';
import { Button } from './components/ui/button.jsx';
import { Card, CardContent } from './components/ui/card.jsx';
import { motion } from 'framer-motion';

const STORE = {
  name: 'CSC Quick Stop Kitchen',
  phone: '802-495-0768',
  address: '1563 North Ave, Burlington, VT 05408',
  note: 'Available Food — Tuesday kitchen closed. Pickup only (no delivery).',
};

const ITEMS = [
  { id: 'veg-mix-veg-curry', name: 'Mix Veg Curry', price: 12.99, category: 'Veg' },
  { id: 'veg-biryani', name: 'Veg Biryani', price: 12.99, category: 'Veg' },
  { id: 'veg-chowmein', name: 'Veg Chowmein', price: 11.99, category: 'Veg' },
  { id: 'veg-momo', name: 'Veg Momo', price: 11.99, category: 'Veg' },
  { id: 'veg-chilli-momo', name: 'Chilli Veg Momo', price: 12.99, category: 'Veg' },
  { id: 'veg-fried-rice', name: 'Veg Fried Rice', price: 9.99, category: 'Veg' },
  { id: 'veg-korma', name: 'Veg Korma', price: 13.99, category: 'Veg' },
  { id: 'veg-aloo-matar', name: 'Aloo Matar', price: 12.99, category: 'Veg' },
  { id: 'veg-paneer-korma', name: 'Paneer Korma', price: 14.99, category: 'Veg' },
  { id: 'veg-mutter-paneer', name: 'Motter Paneer', price: 13.99, category: 'Veg' },
  { id: 'veg-thukpa', name: 'Veg Thukpa', price: 12.99, category: 'Veg' },
  { id: 'veg-dal-makhani', name: 'Dal Makhani', price: 13.99, category: 'Veg' },
  { id: 'veg-dal-tadka', name: 'Dal Tadka (Yellow)', price: 12.99, category: 'Veg' },
  { id: 'veg-pakora', name: 'Veg Pakora', price: 4.99, category: 'Veg' },
  { id: 'veg-samosa', name: 'Veg Samosa (each)', price: 2.99, category: 'Veg', meta: '2 for $5.00' },
  { id: 'veg-mix-coconut-curry', name: 'Mix Veg Coconut Curry', price: 14.99, category: 'Veg' },
  { id: 'veg-okra-masala', name: 'Okra Masala', price: 12.99, category: 'Veg' },
  { id: 'veg-paneer-tikka-masala', name: 'Paneer Tika Masala', price: 13.99, category: 'Veg' },
  { id: 'veg-butter-paneer', name: 'Butter Paneer', price: 13.99, category: 'Veg' },

  { id: 'nv-chicken-curry', name: 'Chicken Curry', price: 14.99, category: 'Non Veg' },
  { id: 'nv-lamb-curry', name: 'Lamb Curry', price: 15.99, category: 'Non Veg' },
  { id: 'nv-goat-curry', name: 'Goat Curry', price: 16.99, category: 'Non Veg' },
  { id: 'nv-chicken-biryani', name: 'Chicken Biryani', price: 14.99, category: 'Non Veg' },
  { id: 'nv-lamb-biryani', name: 'Lamb Biryani', price: 15.99, category: 'Non Veg' },
  { id: 'nv-goat-biryani', name: 'Goat Biryani', price: 16.99, category: 'Non Veg' },
  { id: 'nv-chicken-chowmein', name: 'Chicken Chowmein', price: 12.99, category: 'Non Veg' },
  { id: 'nv-pork-chowmein', name: 'Pork Chowmein', price: 11.99, category: 'Non Veg' },
  { id: 'nv-chicken-fried-rice', name: 'Chicken Fried Rice', price: 11.99, category: 'Non Veg' },
  { id: 'nv-chicken-momo', name: 'Chicken Momo', price: 12.99, category: 'Non Veg' },
  { id: 'nv-chicken-thukpa', name: 'Chicken Thukpa', price: 13.99, category: 'Non Veg' },
  { id: 'nv-chicken-chili-momo', name: 'Chicken Chili Momo', price: 14.99, category: 'Non Veg' },
  { id: 'nv-chicken-chilli', name: 'Chicken Chilli', price: 14.99, category: 'Non Veg' },
  { id: 'nv-chicken-sekuwa', name: 'Chicken Sekuwa', price: 11.99, category: 'Non Veg' },
  { id: 'nv-chicken-korma', name: 'Chicken Korma', price: 15.99, category: 'Non Veg' },
  { id: 'nv-lamb-korma', name: 'Lamb Korma', price: 16.99, category: 'Non Veg' },
  { id: 'nv-chicken-coconut-curry', name: 'Chicken Coconut Curry', price: 15.99, category: 'Non Veg' },
  { id: 'nv-lamb-coconut-curry', name: 'Lamb Coconut Curry', price: 16.99, category: 'Non Veg' },
  { id: 'nv-butter-chicken', name: 'Butter Chicken', price: 15.99, category: 'Non Veg' },

  { id: 'drink-mango-lassi', name: 'Mango Lassi', price: 4.99, category: 'Drinks/Dish' },
  { id: 'side-raita', name: 'Raita', price: 2.99, category: 'Drinks/Dish' },
  { id: 'side-tamarind-chutney', name: 'Tamarind Chutney', price: 2.99, category: 'Drinks/Dish' },
  { id: 'side-mint-chutney', name: 'Mint Chutney', price: 2.99, category: 'Drinks/Dish' },
];

function groupByCategory(items) {
  return items.reduce((acc, item) => {
    acc[item.category] ||= [];
    acc[item.category].push(item);
    return acc;
  }, {});
}

export default function App() {
  const [cart, setCart] = useState([]);
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('All');
  const [tip, setTip] = useState(0);
  const [customTip, setCustomTip] = useState('');

  const categories = useMemo(() => ['All', ...new Set(ITEMS.map(i => i.category))], []);

  const filtered = useMemo(() =>
    ITEMS.filter(i =>
      (category === 'All' || i.category === category) &&
      i.name.toLowerCase().includes(query.toLowerCase())
    ),
  [query, category]);

  const groups = groupByCategory(filtered);

  function addToCart(item) {
    setCart(prev => {
      const existing = prev.find(i => i.id === item.id);
      if (existing) {
        return prev.map(i => i.id === item.id ? { ...i, qty: i.qty + 1 } : i);
      }
      return [...prev, { ...item, qty: 1 }];
    });
  }

  function updateQty(id, qty) {
    setCart(prev => prev
      .map(i => i.id === id ? { ...i, qty: Math.max(1, qty) } : i)
      .filter(i => i.qty > 0));
  }

  const subtotal = cart.reduce((s, i) => s + i.price * i.qty, 0);
  const appliedTip = customTip !== '' ? (parseFloat(customTip) || 0) : tip;
  const total = subtotal + appliedTip;

  async function handleCheckout() {
    try {
      const res = await fetch('/api/create-checkout-session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          cart: cart.map(i => ({ name: i.name, price: i.price, qty: i.qty })),
          tip: appliedTip
        }),
      });
      const data = await res.json();
      if (data?.url) {
        window.location.href = data.url;
      } else {
        alert('Checkout failed.');
      }
    } catch (e) {
      console.error(e);
      alert('Checkout error.');
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <header className="max-w-6xl mx-auto flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">🍽️ {STORE.name}</h1>
          <p className="text-gray-600">{STORE.address} • {STORE.phone}</p>
          <p className="text-sm text-amber-700 font-medium">{STORE.note}</p>
        </div>
        <div className="flex gap-2">
          <input
            className="px-3 py-2 rounded-xl border w-56"
            placeholder="Search menu..."
            value={query}
            onChange={e => setQuery(e.target.value)}
          />
          <select
            className="px-3 py-2 rounded-xl border"
            value={category}
            onChange={e => setCategory(e.target.value)}
          >
            {categories.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
      </header>

      <main className="max-w-6xl mx-auto mt-8 grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-10">
          {Object.keys(groups).length === 0 && (
            <p className="text-gray-500">No items match your search.</p>
          )}
          {Object.entries(groups).map(([cat, list]) => (
            <section key={cat}>
              <h2 className="text-2xl font-semibold mb-4">{cat}</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {list.map((item) => (
                  <motion.div key={item.id} whileHover={{ scale: 1.03 }}>
                    <Card className="rounded-2xl shadow-md">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between gap-3">
                          <div>
                            <h3 className="text-lg font-medium">{item.name}</h3>
                            <p className="text-gray-500">${item.price.toFixed(2)}</p>
                            {item.meta && <p className="text-xs text-gray-500 mt-1">{item.meta}</p>}
                          </div>
                          <Button onClick={() => addToCart(item)}>Add</Button>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </section>
          ))}
        </div>

        <aside className="bg-white rounded-2xl shadow-lg p-6 h-fit sticky top-6">
          <h2 className="text-2xl font-bold mb-4">🛒 Your Cart</h2>
          {cart.length === 0 ? (
            <p className="text-gray-500">Cart is empty</p>
          ) : (
            <div className="space-y-3">
              {cart.map(item => (
                <div key={item.id} className="flex items-center justify-between gap-3">
                  <div>
                    <p className="font-medium">{item.name}</p>
                    <p className="text-sm text-gray-500">${item.price.toFixed(2)} each</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button size="sm" variant="secondary" onClick={() => updateQty(item.id, item.qty - 1)}>-</Button>
                    <span className="w-6 text-center">{item.qty}</span>
                    <Button size="sm" variant="secondary" onClick={() => updateQty(item.id, item.qty + 1)}>+</Button>
                  </div>
                  <div className="w-20 text-right font-medium">
                    ${(item.price * item.qty).toFixed(2)}
                  </div>
                </div>
              ))}
              <hr className="my-3" />
              <div className="flex items-center justify-between">
                <span className="font-semibold">Subtotal</span>
                <span className="font-semibold">${subtotal.toFixed(2)}</span>
              </div>

              <div className="mt-3">
                <label className="block text-sm font-medium mb-1">Add a Tip:</label>
                <div className="flex gap-2 mb-2">
                  {[0, 2, 5, 10].map(amount => (
                    <Button
                      key={amount}
                      variant={tip === amount && customTip === '' ? 'default' : 'secondary'}
                      onClick={() => { setTip(amount); setCustomTip(''); }}
                    >
                      {amount === 0 ? 'No Tip' : `$${amount}`}
                    </Button>
                  ))}
                </div>
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  className="px-3 py-2 rounded-xl border w-full"
                  placeholder="Custom tip amount"
                  value={customTip}
                  onChange={e => setCustomTip(e.target.value)}
                />
              </div>

              <div className="flex items-center justify-between mt-3">
                <span className="font-semibold">Total</span>
                <span className="font-semibold">${total.toFixed(2)}</span>
              </div>

              <Button className="w-full mt-3" onClick={handleCheckout}>Place Pickup Order</Button>
              <p className="text-xs text-gray-500">
                *Pickup only, no delivery. You will be redirected to Stripe Checkout.
              </p>
            </div>
          )}
        </aside>
      </main>
    </div>
  );
}
