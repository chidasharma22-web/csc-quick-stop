export function Button({ children, variant = 'default', size = 'md', className = '', ...props }) {
  const base = 'rounded-2xl px-4 py-2 transition shadow-sm';
  const variants = {
    default: 'bg-black text-white hover:opacity-90',
    secondary: 'bg-gray-100 hover:bg-gray-200',
    destructive: 'bg-red-500 text-white hover:bg-red-600',
  };
  const sizes = {
    sm: 'text-sm px-3 py-1.5',
    md: '',
    lg: 'text-lg px-5 py-3',
  };
  return (
    <button className={[base, variants[variant] || variants.default, sizes[size] || sizes.md, className].join(' ')} {...props}>
      {children}
    </button>
  );
}
