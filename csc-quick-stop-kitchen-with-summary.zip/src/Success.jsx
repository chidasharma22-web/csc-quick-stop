
import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";

export default function Success() {
  const [searchParams] = useSearchParams();
  const sessionId = searchParams.get("session_id");
  const [order, setOrder] = useState(null);

  useEffect(() => {
    async function fetchOrder() {
      if (!sessionId) return;
      try {
        const res = await fetch(`/api/get-session?session_id=${sessionId}`);
        const data = await res.json();
        setOrder(data);
      } catch (err) {
        console.error(err);
      }
    }
    fetchOrder();
  }, [sessionId]);

  if (!sessionId) {
    return (
      <div className="flex flex-col items-center justify-center h-screen text-center">
        <h1 className="text-2xl font-bold">✅ Thank you!</h1>
        <p>No session ID found. Your order should still be on its way.</p>
        <a href="/" className="mt-6 px-4 py-2 bg-green-600 text-white rounded-lg shadow hover:bg-green-700">
          Back to Menu
        </a>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-6 text-center">
      <h1 className="text-3xl font-bold text-green-600">✅ Thank you for your order!</h1>
      {!order ? (
        <p className="mt-4 text-lg">Loading order details...</p>
      ) : (
        <div className="mt-6 w-full max-w-md bg-white shadow rounded-lg p-6 text-left">
          <h2 className="text-xl font-semibold mb-4">Order Summary</h2>
          <ul className="space-y-2">
            {order.items.map((item, i) => (
              <li key={i} className="flex justify-between">
                <span>{item.description} x {item.quantity}</span>
                <span>${(item.amount_total / 100).toFixed(2)}</span>
              </li>
            ))}
          </ul>
          <hr className="my-4"/>
          <div className="flex justify-between font-bold">
            <span>Total</span>
            <span>${(order.total / 100).toFixed(2)}</span>
          </div>
        </div>
      )}
      <a href="/" className="mt-6 px-4 py-2 bg-green-600 text-white rounded-lg shadow hover:bg-green-700">
        Back to Menu
      </a>
    </div>
  );
}
