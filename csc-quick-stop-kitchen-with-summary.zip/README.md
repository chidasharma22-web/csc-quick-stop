# CSC Quick Stop Kitchen — Ready to Deploy

A pickup-only online ordering site with Stripe Checkout.

## Deploy (Vercel)
1. Install Vercel CLI: `npm i -g vercel`
2. From this folder, run: `vercel` (first time) then `vercel --prod` (to make it permanent)
3. In Vercel dashboard → Project Settings → Environment Variables, add:
   - `STRIPE_SECRET_KEY` = your Stripe secret key (starts with `sk_...`)
4. Visit your public URL and try a test purchase.

## Local Dev
```bash
npm install
npm run dev
# open http://localhost:5173
```
Stripe API runs as a serverless function at `/api/create-checkout-session` when deployed.
