
import Stripe from "stripe";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

export default async function handler(req, res) {
  try {
    const session = await stripe.checkout.sessions.retrieve(req.query.session_id, {
      expand: ["line_items"]
    });

    res.status(200).json({
      id: session.id,
      total: session.amount_total,
      items: session.line_items.data.map(item => ({
        description: item.description,
        quantity: item.quantity,
        amount_total: item.amount_total
      }))
    });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
}
